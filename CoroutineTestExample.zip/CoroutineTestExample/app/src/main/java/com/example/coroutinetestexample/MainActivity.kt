package com.example.coroutinetestexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.example.coroutinetestexample.adapter.MovieAdapter
import com.example.coroutinetestexample.databinding.ActivityMainBinding
import com.example.coroutinetestexample.remote.Repository
import com.example.coroutinetestexample.remote.RetrofitService
import com.example.coroutinetestexample.viewmodel.MovieViewModel
import com.example.coroutinetestexample.viewmodel.MovieViewModelFactory

class MainActivity : AppCompatActivity() {

    lateinit var viewmodel :MovieViewModel
    private val adapter= MovieAdapter()
    lateinit var binding :ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding= ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        val retrofitService= RetrofitService.getInstance()
        val repository = Repository(retrofitService)

        viewmodel= ViewModelProvider(this,MovieViewModelFactory(repository)).get(MovieViewModel::class.java)

         binding.recyclerview.adapter = adapter

         viewmodel.movielist.observe(this)
         {
             adapter.setMovies(it)
         }

        viewmodel.errormsg.observe(this)
        {

        }

         viewmodel.loading.observe(this,{
             if(it)
             {
                 binding.progressDialog.visibility= View.VISIBLE
             }
             else
             {
                 binding.progressDialog.visibility= View.GONE
             }
         })
        viewmodel.getMovies()


    }
}