package com.example.coroutinetestexample.remote

class Repository  constructor(private val retrofitService: RetrofitService){

    suspend fun getMovies()=retrofitService.getMovies()




}