package com.example.coroutinetestexample.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.coroutinetestexample.databinding.MovielayoutBinding
import com.example.coroutinetestexample.model.Movie
import com.squareup.picasso.Picasso

class MovieAdapter : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    var movielist= mutableListOf<Movie>()

    class MovieViewHolder(val binding: MovielayoutBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {

        val inflator= LayoutInflater.from(parent.context)
        val binding = MovielayoutBinding.inflate(inflator,parent,false)
        return MovieViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {


        val movie = movielist[position]
        holder.binding.name.text= movie.name
        Picasso.get().load(movie.imageUrl).into(holder.binding.imageview)
    }

    override fun getItemCount(): Int {

        return movielist.size
    }
    fun setMovies(movie: List<Movie>)
    {
        this.movielist=movie.toMutableList()
        notifyDataSetChanged()
    }
}