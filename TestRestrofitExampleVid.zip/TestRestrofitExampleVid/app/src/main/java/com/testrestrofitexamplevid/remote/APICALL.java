package com.testrestrofitexamplevid.remote;

import com.testrestrofitexamplevid.model.EmployeeList;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by lenovo on 3/18/2018.
 */

public interface APICALL {


    @GET("/test/first.json")
    Call<EmployeeList> getEmployeeList();

}
